sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("cap.issue.rawdatafile.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map